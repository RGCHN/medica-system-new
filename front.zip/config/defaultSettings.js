const Settings = {
  navTheme: 'light',
  primaryColor: "#722ED1",
  layout: 'side',
  contentWidth: 'Fluid',
  fixedHeader: false,
  fixSiderbar: true,
  colorWeak: false,
  splitMenus: false,
  title: '脑卒中AI助诊',
  pwa: false,
  iconfontUrl: '',
};
export default Settings;
