(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_dumi-theme-default_es_builtins_Badge_js_js"],{

/***/ "./node_modules/dumi-theme-default/es/builtins/Badge.less":
/*!****************************************************************!*\
  !*** ./node_modules/dumi-theme-default/es/builtins/Badge.less ***!
  \****************************************************************/
/***/ (function() {

// extracted by mini-css-extract-plugin
    if(false) { var cssReload; }
  

/***/ }),

/***/ "./node_modules/dumi-theme-default/es/builtins/Badge.js":
/*!**************************************************************!*\
  !*** ./node_modules/dumi-theme-default/es/builtins/Badge.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _Badge_less__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Badge.less */ "./node_modules/dumi-theme-default/es/builtins/Badge.less");
/* harmony import */ var _Badge_less__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Badge_less__WEBPACK_IMPORTED_MODULE_1__);
function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



/* harmony default export */ __webpack_exports__["default"] = (function (props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", _extends({
    className: "__dumi-default-badge"
  }, props));
});

/***/ }),

/***/ "./src/.umi/.cache/.mfsu/mf-va_dumi-theme-default_es_builtins_Badge.js.js":
/*!********************************************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_dumi-theme-default_es_builtins_Badge.js.js ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Code_test_myapp_node_modules_dumi_theme_default_es_builtins_Badge_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/dumi-theme-default/es/builtins/Badge.js */ "./node_modules/dumi-theme-default/es/builtins/Badge.js");

/* harmony default export */ __webpack_exports__["default"] = (D_Code_test_myapp_node_modules_dumi_theme_default_es_builtins_Badge_js__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ })

}]);