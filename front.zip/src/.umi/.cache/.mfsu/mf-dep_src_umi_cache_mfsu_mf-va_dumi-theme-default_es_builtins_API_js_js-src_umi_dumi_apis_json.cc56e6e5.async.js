(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_dumi-theme-default_es_builtins_API_js_js-src_umi_dumi_apis_json"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_dumi-theme-default_es_builtins_API.js.js":
/*!******************************************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_dumi-theme-default_es_builtins_API.js.js ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Code_test_myapp_node_modules_dumi_theme_default_es_builtins_API_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/dumi-theme-default/es/builtins/API.js */ "./node_modules/dumi-theme-default/es/builtins/API.js");

/* harmony default export */ __webpack_exports__["default"] = (D_Code_test_myapp_node_modules_dumi_theme_default_es_builtins_API_js__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ }),

/***/ "./src/.umi/dumi/apis.json":
/*!*********************************!*\
  !*** ./src/.umi/dumi/apis.json ***!
  \*********************************/
/***/ (function(module) {

"use strict";
module.exports = {};

/***/ })

}]);